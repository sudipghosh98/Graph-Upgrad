import java.util.*;

class GraphAssignment{

      static  HashMap<String, LinkedList<node>> allRoute=new HashMap<>();

     static    HashMap<String, Integer> allCities=new HashMap<>();


      public static void readMap(Scanner scanner) {
        while (true) {
            String mapLine = scanner.nextLine();
            if (mapLine.equals("")) {
                break;
            }
        readLine(mapLine);
        }
      

    }
 

	  public static void readLine(String line) {
        String[] csv = line.split(",");
        String source = csv[0].trim();
        String destination = csv[1].trim();
     

            int distance=-1;
            if(csv.length==3)
            {
                distance=Integer.parseInt(csv[2].trim());
            }
            node node1=new node(destination, distance);
            node node2=new node(source, distance);

            // Enter all the source to destination
            if(allRoute.containsKey(source))
            {
                LinkedList<node> linkedList=allRoute.get(source);
                linkedList.addLast(node1);
                allRoute.put(source, linkedList);
            }
            else
            {
                LinkedList<node> linkedList=new LinkedList<>();
                linkedList.addLast(node1);
                allRoute.put(source,linkedList);
                allCities.put(source, Integer.MAX_VALUE);
            }


            // Enter all the destination to source
            if(allRoute.containsKey(destination))
            {
                LinkedList<node> linkedList=allRoute.get(destination);
                linkedList.add(node2);
                allRoute.put(destination, linkedList);
            }
            else
            {
                LinkedList<node> linkedList=new LinkedList<>();
                linkedList.add(node2);
                allRoute.put(destination, linkedList);
                allCities.put(destination, Integer.MAX_VALUE);
            }
        
    }

     public static void findSafestRouteToCity(String source, String destination, HashMap<String, LinkedList<node>> allRoute, HashMap<String, Integer> allCities)
    {

        //  Dijkstra Algorithm
        PriorityQueue<String> priorityQueue=new PriorityQueue<>(new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                return allCities.get(o1)-allCities.get(o2);
            }
        });

        boolean bool1=false;
        HashMap<String, String> parent=new HashMap<>();

        allCities.put(source, Integer.MAX_VALUE);
        priorityQueue.add(source);

        me1: while (!priorityQueue.isEmpty())
        {
            String first=priorityQueue.poll();
            int firstDistance=allCities.get(first);

            for(node node00 : allRoute.get(first))
            {
                String dest=node00.destination;
                int dist=node00.distance;

                if(dist!=Integer.MAX_VALUE)
                {
                    int newDist=firstDistance+dist;
                    int curDist=allCities.get(dest);

                    if(newDist<curDist)
                    {
                        allCities.put(dest, newDist);
                        parent.put(dest, first);
                        priorityQueue.add(dest);

                        if(dest.equals(destination))
                        {
                            bool1=true;
                            break me1;
                        }
                    }
                }
            }
        }

        if(bool1)
        {
            ArrayList<String> arrayList=new ArrayList<>();

            String cityParent=destination;
            while (!cityParent.equals(source))
            {
                arrayList.add(cityParent);
                cityParent=parent.get(cityParent);
            }
            arrayList.add(source);

            Collections.reverse(arrayList);

            int size=arrayList.size();
            for(int i=0;i<size-1;i++)
            {
                System.out.print(arrayList.get(i)+" -> ");
            }
            System.out.print(arrayList.get(size-1));
            System.out.println();
        }
        else
        {
            System.out.println("Not Recommended");
        }
    }

 

   public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Map");
        readMap(scanner);

        System.out.println("Enter the source ");
        String source = scanner.nextLine();
        System.out.println("Enter the destination ");
        String destination = scanner.nextLine();
        System.out.println("The route from "+source+" to "+destination+" is");

  findSafestRouteToCity(source, destination, allRoute, allCities);
    }


}
class node
{
    String destination;
    int distance;
    node(String destination, int distance)
    {
        this.destination=destination;
        this.distance=distance;
    }
}