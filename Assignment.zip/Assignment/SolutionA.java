import java.util.*;

class GraphAssignment
{
     static  HashMap<String, HashSet<String>> allRoute=new HashMap<>();
    public static void readMap(Scanner scanner) {
        while (true) {
            String mapLine = scanner.nextLine();
            if (mapLine.equals("")) {
                break;
            }
        readLine(mapLine);
        }
      

    }
 

          public static void readLine(String line) {
        String[] csv = line.split(",");
        String source = csv[0];
        String dest = csv[1];

          if(allRoute.containsKey(source))
            {
                HashSet<String> hashSet=allRoute.get(source);
                hashSet.add(dest);
                allRoute.put(source, hashSet);
            }
            else
            {
                HashSet<String> hashSet=new HashSet<>();
                hashSet.add(dest);
                allRoute.put(source,hashSet);
            }


            // Enter all the destination to source
            if(allRoute.containsKey(dest))
            {
                HashSet<String> hashSet=allRoute.get(dest);
                hashSet.add(source);
                allRoute.put(dest, hashSet);
            }
            else
            {
                HashSet<String> hashSet=new HashSet<>();
                hashSet.add(source);
                allRoute.put(dest,hashSet);
            }
     
    }

    public static void findAnyRouteToCity(String source, String dest, HashMap<String, HashSet<String>> allRoute)
    {
        Queue<String> queue=new LinkedList<>();
        queue.add(source);

        HashSet<String> visited=new HashSet<>();
        visited.add(source);

        HashMap<String, String> parent=new HashMap<>();
        boolean bool1=false;
        me1: while (!queue.isEmpty())
        {
            String first=queue.poll();

            for(String city : allRoute.get(first))
            {
                if(!visited.contains(city))
                {
                    queue.add(city);
                    visited.add(city);
                    parent.put(city,first);

                    if(city.equals(dest))
                    {
                        bool1=true;
                        break me1;
                    }
                }
            }
        }

        if(bool1)
        {
           
            String parentCity=dest;
            ArrayList<String> arrayList=new ArrayList<>();
            while (!parentCity.equals(source))
            {
                arrayList.add(parentCity);
                parentCity=parent.get(parentCity);
            }
            arrayList.add(source);
            Collections.reverse(arrayList);
            int size=arrayList.size();
            for(int i=0;i<size-1;i++)
            {
                System.out.print(arrayList.get(i)+" -> ");
            }
            System.out.print(arrayList.get(size-1));
            System.out.println();
        }
        else
        {
            System.out.println("Not Reachable");
        }
    }

    public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the Map");
        readMap(scanner);

        System.out.println("Enter the source ");
        String source = scanner.nextLine();
        System.out.println("Enter the destination ");
        String destination = scanner.nextLine();
        System.out.println("The route from "+source+" to "+destination+" is");

       findAnyRouteToCity(source,destination, allRoute);
    }



}